import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'premier-league';
  toogle = true;

  //show or hide the navigation bar
  toogleSideBar():void{
	  this.toogle = !this.toogle
  }
}
